from flask import Flask, render_template, request, jsonify
import os

from agents.reader_agent import read_document
from agents.summary_agent import generate_summary
from agents.question_agent import extract_questions
from agents.keyword_agent import extract_keywords, highlight_keywords

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


@app.route("/")
def home():
    return render_template(
        "index.html",
        summary=None,
        questions=None,
        keywords=None,
        highlighted_text=None,
        filename=None,
        error=None,
        top_n=8,
    )


@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        file  = request.files.get("file")
        top_n = int(request.form.get("top_n", 8))

        if not file or file.filename == "":
            return render_template("index.html", error="Please upload a file",
                                   top_n=top_n)

        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)

        # ── Read document ──────────────────────────────────────────────────
        text = read_document(file_path)
        if not text:
            return render_template("index.html", error="No text extracted",
                                   top_n=top_n)

        # ── Generate summary ───────────────────────────────────────────────
        summary = generate_summary(text)

        # ── Extract questions ──────────────────────────────────────────────
        questions = extract_questions(text)

        # ── Extract keywords ───────────────────────────────────────────────
        keywords = extract_keywords(text, top_n=top_n)

        # ── Highlight keywords in raw text ─────────────────────────────────
        highlighted_text = highlight_keywords(text[:2000], keywords)

        return render_template(
            "index.html",
            summary=summary,
            questions=questions,
            keywords=keywords,
            highlighted_text=highlighted_text,
            filename=file.filename,
            error=None,
            top_n=top_n,
        )

    except Exception as e:
        return render_template("index.html", error=str(e), top_n=8)


# ── JSON API endpoint (optional) ───────────────────────────────────────────
@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    """
    Returns JSON:  { "summary": "...", "keywords": [...] }
    Usage: POST multipart/form-data with fields 'file' and optional 'top_n'.
    """
    try:
        file  = request.files.get("file")
        top_n = int(request.form.get("top_n", 8))

        if not file or file.filename == "":
            return jsonify({"error": "No file provided"}), 400

        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)

        text = read_document(file_path)
        if not text:
            return jsonify({"error": "No text extracted"}), 422

        summary  = generate_summary(text)
        keywords = extract_keywords(text, top_n=top_n)

        return jsonify({"summary": summary, "keywords": keywords})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)