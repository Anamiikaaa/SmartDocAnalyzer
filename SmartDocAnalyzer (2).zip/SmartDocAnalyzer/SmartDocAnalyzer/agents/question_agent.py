import re

def extract_questions(text):
    lines = text.split("\n")
    questions = []

    for line in lines:
        line = line.strip()

        if not line:
            continue

        # Skip long paragraphs
        if len(line.split()) > 12:
            continue

        # Skip headings like 1.1
        if re.match(r"^\d+(\.\d+)+", line):
            continue

        # Skip bullets
        if line.startswith("•"):
            continue

        # Skip ALL CAPS
        if line.isupper():
            continue

        # ✅ Real questions
        if line.endswith("?"):
            questions.append(line)
            continue

        # ✅ Question words
        if re.match(r"^(What|Why|How|When|Where|Explain|Define)\b", line, re.IGNORECASE):
            questions.append(line)
            continue

        # 🔥 FULL VALUE FORM FIELD (FIXED)
        match = re.match(r"^([A-Z][A-Za-z ]{1,30}):\s*(.*)$", line)

        if match:
            label = match.group(1)
            value = match.group(2).strip()

            # Only include if value exists
            if value:
                questions.append(f"{label}: {value}")

            continue

    if not questions:
        return ["No questions found (only content detected)."]

    return questions