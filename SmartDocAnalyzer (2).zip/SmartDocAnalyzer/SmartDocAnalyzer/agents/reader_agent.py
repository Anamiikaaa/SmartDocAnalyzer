import pandas as pd
import PyPDF2
from docx import Document
import re


def clean_text(text):
    # Remove standalone numbers (page numbers)
    text = re.sub(r'\b\d+\b', '', text)

    # Remove extra newlines
    text = re.sub(r'\n+', ' ', text)

    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text)

    return text.strip()


def read_pdf(file_path):
    text = ""
    with open(file_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        for page in reader.pages:
            extracted = page.extract_text()
            if extracted:
                text += extracted + "\n"

    return clean_text(text)


def read_docx(file_path):
    doc = Document(file_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return clean_text(text)


def read_excel(file_path):
    df = pd.read_excel(file_path)
    return clean_text(df.to_string())


def read_document(file_path):
    if file_path.endswith(".pdf"):
        return read_pdf(file_path)
    elif file_path.endswith(".docx"):
        return read_docx(file_path)
    elif file_path.endswith(".xlsx"):
        return read_excel(file_path)
    else:
        return ""