"""
keyword_agent.py
----------------
Extracts the top N most important keywords from a document using a
hybrid approach:
  1. RAKE  (Rapid Automatic Keyword Extraction) – phrase-aware, fast.
  2. TF-IDF fallback  – single-word scoring when RAKE yields too few phrases.

The two candidate pools are merged, de-duplicated, and returned as a
clean ranked list.  Stopwords are filtered at every stage.
"""

import re
import math
from collections import Counter

from rake_nltk import Rake
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords

# ── shared stopword set ────────────────────────────────────────────────────
_STOP = set(stopwords.words("english"))
# extra noise words common in documents
_STOP.update({"also", "us", "one", "would", "could", "may", "many",
              "use", "used", "using", "like", "well", "much", "two",
              "new", "per", "via", "etc", "within", "without"})


# ── helpers ────────────────────────────────────────────────────────────────

def _clean(text: str) -> str:
    """Basic normalisation: lowercase, collapse whitespace."""
    text = re.sub(r"\s+", " ", text.lower())
    return text.strip()


def _is_meaningful(phrase: str) -> bool:
    """Return True when a phrase has at least one non-stopword token."""
    tokens = re.findall(r"[a-z]+", phrase.lower())
    return any(t not in _STOP and len(t) > 2 for t in tokens)


# ── RAKE extraction ────────────────────────────────────────────────────────

def _rake_keywords(text: str, top_n: int) -> list[str]:
    """Return up to top_n keyword phrases via RAKE."""
    r = Rake(stopwords=_STOP, min_length=1, max_length=3)
    r.extract_keywords_from_text(text)
    ranked = r.get_ranked_phrases()  # already sorted by score descending

    seen, results = set(), []
    for phrase in ranked:
        phrase = phrase.strip()
        if not _is_meaningful(phrase):
            continue
        key = phrase.lower()
        if key not in seen:
            seen.add(key)
            results.append(phrase)
        if len(results) >= top_n * 2:   # gather extra; trim later
            break
    return results


# ── TF-IDF extraction ──────────────────────────────────────────────────────

def _tfidf_keywords(text: str, top_n: int) -> list[str]:
    """Return up to top_n single-word keywords via TF-IDF."""
    # Split text into pseudo-sentences so TF-IDF has multiple 'documents'
    sentences = re.split(r"[.!?]\s+", text)
    sentences = [s for s in sentences if len(s.split()) >= 3]

    if not sentences:
        sentences = [text]          # fallback: treat whole doc as one unit

    try:
        vec = TfidfVectorizer(
            stop_words=list(_STOP),
            ngram_range=(1, 2),
            max_features=200,
            sublinear_tf=True,
        )
        matrix = vec.fit_transform(sentences)
    except ValueError:
        return []

    # Sum TF-IDF scores across all sentences for each term
    scores = dict(zip(vec.get_feature_names_out(),
                      matrix.sum(axis=0).A1))

    # Filter out single-character tokens and pure-digit tokens
    scores = {k: v for k, v in scores.items()
              if len(k) > 2 and not k.isdigit() and _is_meaningful(k)}

    ranked = sorted(scores, key=scores.get, reverse=True)
    return ranked[:top_n * 2]


# ── public API ─────────────────────────────────────────────────────────────

def extract_keywords(text: str, top_n: int = 8) -> list[str]:
    """
    Extract the top `top_n` keywords from `text`.

    Strategy
    --------
    1. Run RAKE to get high-quality multi-word phrases.
    2. Run TF-IDF to fill any gaps with scored single/bi-gram tokens.
    3. Merge & de-duplicate, preserving RAKE candidates first (higher quality).
    4. Return the top `top_n` results, title-cased for readability.

    Parameters
    ----------
    text   : raw document text
    top_n  : number of keywords to return (default 8, clamped 5–15)

    Returns
    -------
    list[str]  – e.g. ["Machine Learning", "neural network", "feature extraction"]
    """
    top_n = max(5, min(top_n, 15))   # clamp to sensible range

    if not text or not text.strip():
        return []

    cleaned = _clean(text)

    rake_kws  = _rake_keywords(cleaned, top_n)
    tfidf_kws = _tfidf_keywords(cleaned, top_n)

    # Merge: RAKE first, then TF-IDF fill-ins
    seen, merged = set(), []
    for kw in rake_kws + tfidf_kws:
        key = kw.lower()
        if key not in seen:
            seen.add(key)
            merged.append(kw)

    # Title-case multi-word phrases; lowercase single words look better
    final = []
    for kw in merged[:top_n]:
        tokens = kw.split()
        final.append(" ".join(t.capitalize() for t in tokens)
                     if len(tokens) > 1 else kw.lower())

    return final


def highlight_keywords(text: str, keywords: list[str]) -> str:
    """
    Wrap each found keyword in the text with <mark> tags (HTML).
    Case-insensitive, preserves original casing in the output.

    Parameters
    ----------
    text     : original document text
    keywords : list of keyword strings to highlight

    Returns
    -------
    str – HTML-safe text with <mark>…</mark> around matches
    """
    if not keywords or not text:
        return text

    # Sort longest first to avoid partial replacements
    sorted_kws = sorted(keywords, key=len, reverse=True)

    # Escape text for HTML, then apply <mark> tags
    import html as html_mod
    safe = html_mod.escape(text)

    for kw in sorted_kws:
        pattern = re.compile(re.escape(kw), re.IGNORECASE)
        safe = pattern.sub(lambda m: f"<mark>{m.group()}</mark>", safe)

    return safe
