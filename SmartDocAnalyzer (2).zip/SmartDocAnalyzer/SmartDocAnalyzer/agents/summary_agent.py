import re
from collections import Counter

def generate_summary(text):

    # 🔥 Clean numbers
    text = re.sub(r'\b\d+\b', '', text)

    # 🔥 Remove ALL CAPS headings
    text = re.sub(r'\b[A-Z\s]{5,}\b', '', text)

    # 🔥 Normalize spacing
    text = re.sub(r'\s+', ' ', text)

    # 🔹 Split sentences
    sentences = re.split(r'[.!?]', text)

    cleaned = []
    for s in sentences:
        s = s.strip()

        # ❌ Remove very short lines
        if len(s) < 40:
            continue

        # ❌ Remove lines without verbs (likely headings)
        if not re.search(r'\b(is|are|was|were|has|have|provides|detects|uses)\b', s.lower()):
            continue

        cleaned.append(s)

    # Remove duplicates
    cleaned = list(dict.fromkeys(cleaned))

    # 🔹 Word frequency
    words = re.findall(r'\w+', text.lower())
    stopwords = set(["the","is","in","and","to","of","a","with","for","on"])

    words = [w for w in words if w not in stopwords]
    freq = Counter(words)

    # 🔹 Score sentences
    scores = {}
    for s in cleaned:
        s_words = re.findall(r'\w+', s.lower())
        score = sum(freq.get(w, 0) for w in s_words)

        if len(s_words) > 0:
            score /= len(s_words)

        scores[s] = score

    # 🔹 Select top
    top = sorted(scores, key=scores.get, reverse=True)[:6]

    final = [s for s in cleaned if s in top]

    return "\n\n".join(final)